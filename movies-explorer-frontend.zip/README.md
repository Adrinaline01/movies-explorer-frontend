Ссылка на макет: https://www.figma.com/file/6FMWkB94wE7KTkcCgUXtnC/Дипломный-проект?type=design&node-id=1-7852&mode=design&t=S6oGDUwxFR73WPli-0

Ссылка на Frontend: adrinalinediploma.nomoredomainsrocks.ru
Ссылка на Pull Request: https://github.com/Adrinaline01/movies-explorer-frontend/tree/level-3